                                <div class="card mb-4">
                                        <div class="card-header text-primary font-weight-bold">Thông tin chi tiết đơn nhập</div>
                                        <div class="card-body"> 
                                            <div class="mb-3 row">
                                                <div class="col-3">
                                            
                                                </tbody>
                                            </table>
                                                <a class="btn btn-success" href="{{route('admin.purchase.print')}}">in PDF</a>
                                        </div>
                                    </div>