<?php $__env->startSection('title'); ?>
Chi tiết sản phẩm
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  
<h1 class="h3 mb-2 text-gray-800  border-bottom bg-white mb-4"><i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>Chi tiết sản phẩm<a style="float:right;" href="<?php echo e(route('admin.product')); ?>" class="btn btn-danger col-1"><i class="fas fa-sharp fa-solid fa-arrow-left"></i> Quay lại</a></h1>
                        <?php if($errors->any()): ?>
                                    <div class="alert alert-danger">
                                       <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                        <?php endif; ?>   
<div class="card shadow mb-4">
                        
                        
                                    <!-- Account details card-->
                                    <div class="card mb-4">
                                        <div class="card-header text-primary font-weight-bold">Chi tiết sản phẩm</div>
                                        <div class="card-body"> 
                                                    <label class="small mb-1 font-weight-bold" >Tên sản phẩm:</label>
                                                    <label class="font-weight-bold" ><?php echo e($product->name); ?></label>
                                                <div class="mb-3">  
                                                    <label class="small mb-1 font-weight-bold" >Danh mục: </label>
                                                    <label ><?php echo e($category); ?></label>    
                                                    <label style="margin-left: 5%" class="small mb-1 font-weight-bold">Nhãn hàng: </label>
                                                    <label ><?php echo e($brand); ?></label>    
                                                </div>
                                                <div class="mb-3">
                                                    <?php $__currentLoopData = json_decode($product->image); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <img class="col-2" src="<?php echo e(asset('/admin/assets/img/product/'.$product->id.'/'.$value)); ?>">
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="small mb-1 font-weight-bold">Giá: </label>
                                                    <label><?php echo e(number_format($product->price, 0, ',', '.')); ?></label>   
                                                    <label style="margin-left: 5%" class="small mb-1 font-weight-bold">Giảm giá: </label>
                                                    <?php if($product->discount !=0): ?>
                                                    <label ><?php echo e($product->discount); ?>%</label>
                                                    <?php else: ?>
                                                    <label >Không</label>
                                                    <?php endif; ?>
                                                    <label style="margin-left: 5%" class="small mb-1 font-weight-bold">Số lượng: </label>
                                                    <label ><?php echo e($product->total_qty); ?></label>     
                                                </div>
                                                <?php if($listsize->count() > 0): ?>
                                                <div class="mb-3">  
                                                    <label class="small mb-1 font-weight-bold">Số lượng chi tiết: </label>
                                                    <?php $__currentLoopData = $listsize; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <label style="margin-left:1.5%" class="font-weight-bold">size <?php echo e($value->size); ?>: </label>
                                                    <label><?php echo e($value->size_qty); ?> </label>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                                <?php endif; ?>
                                                <div class="mb-3">
                                                    <label class="small mb-1 font-weight-bold">Mô tả: </label>
                                                    <?php if($product->description): ?>
                                                    <div class="card-body small" style="overflow: hidden;">
                                                    <?php echo $product->description; ?>

                                                    </div>
                                                    <?php else: ?> 
                                                        Chưa có mô tả
                                                    <?php endif; ?>
                                                </div>
                                        </div>
                                    </div>
                     
                        

</div>


<?php $__env->stopSection(); ?>
         
<?php echo $__env->make('Admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\chotsport\resources\views/Admin/product/productDetail.blade.php ENDPATH**/ ?>