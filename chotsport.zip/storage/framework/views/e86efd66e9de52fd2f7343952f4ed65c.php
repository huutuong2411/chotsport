<!-- Start Header Area -->
<?php 
    $categorys = App\Models\Admin\Category::select('name','id')->get();
    $brands = App\Models\Admin\Brand::select('name','id')->get();
?>
    <header class="header-section d-none d-xl-block">
        <div class="header-wrapper">
            <div class="header-bottom header-bottom-color--golden section-fluid  sticky-color--golden">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12 d-flex align-items-center justify-content-between" style="padding-top: 5px">
                             <!-- Start Header Logo -->
                            <div class="header-logo col-2">
                                <div class="logo">
                                    <a href="<?php echo e(route('user.home')); ?>"><img src="<?php echo e(asset('user/assets/images/logo/logo_chot.png')); ?>" alt="" style="width: 200%;"></a>
                                </div>
                            </div>
                            <!-- End Header Logo -->
                            
                            <!-- Start Header Main Menu -->
                           
                            <!-- End Header Main Menu Start -->
                           
                            <div class="col-5 search_form">
                                 <form action="<?php echo e(route('user.search')); ?>">
                                <input class="form-control mr-sm-2" id="inputsearch" name="inputsearch" type="search" placeholder="Tìm kiếm..." aria-label="Search" style="position: relative">
                                <!-- Start Offcanvas Addcart Section -->
                                </form>
                            </div>
                            
                            <!-- Start Header Action Link -->
                            <ul class="header-action-link action-color--black action-hover-color--golden col-5-auto">
                                <li style="margin-right: 20px;">
                                    <a href="#search">
                                        <button type="button" class="btn btn-warning btn-sm">Tư vấn size <i class="fa-solid fa-shoe-prints" style="color: #c8ab19;"></i></button>
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('user.cart')); ?>" >
                                        <i class="icon-bag"></i>
                                        <span class="item-count"><?php echo e(session()->has('cart')?array_sum(array_column(session()->get('cart'), 'cartQty')): 0); ?></span>
                                        
                                    </a>
                                </li>
                                <li>
                                    <div class="dropdown">
                                        <button style="padding: 0px" class="offside-about" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <?php if(Auth::check()): ?>
                                            <?php $avatar= Illuminate\Support\Facades\Auth::user()->avatar; ?>
                                                <?php if($avatar): ?>
                                            <img style="width:85%;height:85%" class="rounded-circle" src="<?php echo e(asset('/user/assets/images/user/'.$avatar)); ?>">  
                                                <?php else: ?>
                                            <i class="fa-regular fa-user" style="color: #000000; font-size: 18px;"></i>    
                                                <?php endif; ?>
                                            <?php else: ?>
                                            <i class="fa-regular fa-user" style="color: #000000; font-size: 18px;"></i>
                                            <?php endif; ?>
                                        </button>
                                        <div class="dropdown-menu dropdown-menu-right" >
                                            <?php if(Auth::check()): ?>
                                        <a class="dropdown-item" style="letter-spacing: -1px;font-size: 20px;" href="<?php echo e(route('user.profile')); ?>">Trang cá nhân</a>
                                        <a class="dropdown-item" style="letter-spacing: -1px;font-size: 20px;"  href="<?php echo e(route('user.order')); ?>">Xem đơn hàng</a>
                                        <a class="dropdown-item" style="letter-spacing: -1px;font-size: 20px;" href="<?php echo e(route('user.logout')); ?>">Đăng xuất</a>
                                            <?php else: ?>
                                        <a class="dropdown-item" style="letter-spacing: -1px; font-size: 20px;" href="<?php echo e(route('user.login')); ?>">Đăng nhập</a>
                                        <a class="dropdown-item" style="letter-spacing: -1px; font-size: 20px;" href="<?php echo e(route('user.register')); ?>">Đăng ký</a>    
                                            <?php endif; ?>
                                      </div>
                                      </div>
                                </li>
                            </ul>
                            <!-- End Header Action Link -->
                        </div>
                    </div>
                </div>
            </div>
            <div class="sticky-header header-bottom header-bottom-color--golden section-fluid  sticky-color--golden">
                <div class="container-fluid">
                    <div class="text-center">
                        <div class="main-menu menu-color--black menu-hover-color--golden col-12" >
                            <nav>
                                <ul>
                                    <li class="has-dropdown">
                                        <a class="active main-menu-link" href="<?php echo e(route('user.home')); ?>">Trang chủ</a>
                                    </li>
                                    <li class="has-dropdown">
                                        <a href="<?php echo e(route('user.allproduct')); ?>">Giày bóng đá <i class="fa fa-angle-down"></i></a>
                                        <!-- Sub Menu -->
                                        <ul class="sub-menu">
                                            <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><a href="<?php echo e(url('/product?category='.$category->id)); ?>"><?php echo e($category->name); ?></a></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </li>
                                    <li class="has-dropdown">
                                        <a href="<?php echo e(route('user.allproduct')); ?>">Thương hiệu<i class="fa fa-angle-down"></i></a>
                                        <!-- Sub Menu -->
                                        <ul class="sub-menu">
                                            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><a href="<?php echo e(url('/product?brand='.$brand->id)); ?>"><?php echo e($brand->name); ?></a></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                        </ul>
                                    </li>
                                    <li class="has-dropdown">
                                        <a id="blog" href="<?php echo e(route('user.blog')); ?>">Bài viết</a>
                                    </li>
                                    <li>
                                        <a href="">Về chúng tôi</a>
                                    </li>
                                    <li>
                                        <a href="">Liên hệ</a>
                                    </li>
                                </ul>
                            </nav>
                        </div>
            </div> 
                </div>
            </div>
            
        </div>
    </header>
    <!-- Start Header Area --><?php /**PATH C:\xampp\htdocs\chotsport\resources\views/User/layout/header.blade.php ENDPATH**/ ?>