<?php $__env->startSection('title'); ?>
Sửa sản phẩm
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  
<h1 class="h3 mb-2 text-gray-800  border-bottom bg-white mb-4"><i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>Sửa sản phẩm<a style="float:right;" href="<?php echo e(route('admin.product')); ?>" class="btn btn-danger btn-sm"><i class="fas fa-sharp fa-solid fa-arrow-left"></i> Quay lại</a></h1>
<div class="card shadow mb-4">

                        
                        <?php if($errors->any()): ?>
                                    <div class="alert alert-danger">
                                       <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                        <?php endif; ?>

                        <form action="" method="post" enctype="multipart/form-data" id="form">
                           <?php echo csrf_field(); ?>
                                
                                    <!-- Account details card-->
                                    <div class="card mb-4">
                                        <div class="card-header text-primary font-weight-bold">Thông tin sản phẩm</div>
                                        <div class="card-body"> 
                                                <div class="mb-3">
                                                    <label class="small mb-1" >Tên sản phẩm</label>
                                                    <input required name="name" class="form-control" type="text" placeholder="Nhập tên sản phẩm" value="<?php echo e($product->name); ?>">
                                                </div>
                                                <div class="mb-3">
                                                    <label class="small mb-1">Hình ảnh</label>
                                                    <div class="row">
                                                        <?php $__currentLoopData = json_decode($product->image); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="col-2 d-flex flex-column  align-items-center showimage" >
                                                            <img style="max-width: 100%" src="<?php echo e(asset('/admin/assets/img/product/'.$product->id.'/'.$value)); ?>">
                                                            <button class="btn btn-danger btn-sm delete" data-image="<?php echo e($value); ?>" type="button">Xoá</button>
                                                        </div class="col-2" >
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <input type="hidden" id="listdelete" name="delete" value="">
                                                    </div>
                                                    <br>
                                                    <input name="image[]" class="form-control col-3" id="uploadimage" type="file"  multiple>
                                                </div>
                                                <div class="mb-3">  
                                                    <label class="small mb-1" >Danh mục: </label>
                                                        <select required class="form-select" name="category" > 
                                                            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option <?php echo e($value->id==$product->id_category? 'selected':''); ?> value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>  
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    <label style="margin-left: 5%" class="small mb-1">Nhãn hàng: </label>
                                                        <select required class="form-select" name="brand" id="brand">
                                                            <?php $__currentLoopData = $brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option <?php echo e($value->id==$product->id_brand? 'selected':''); ?> value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>  
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                </div>
                                                <div class="col-4" id="table_size">
                                                    <table class="table table-bordered">
                                                        <thead>
                                                            <tr>
                                                                <th class="col-5">size</th>
                                                                <th class="col-7">số lượng <button class="btn-outline-dark" type="button" style="float:right" id="none_qty">Chưa có sẵn</button></th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php $__currentLoopData = $size; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td><?php echo e($Size->size); ?></td>
                                                                <td> <input class="size_qty col-10" type="text" name="size_qty_<?php echo e($Size->id); ?>" value="<?php $__currentLoopData = $listsize; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Listsize): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($Listsize->id == $Size->id ?$Listsize->size_qty:''); ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>"></td>
                                                            </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="small mb-1" >Giá</label>
                                                    <input required name="price" class="form-control" type="text" placeholder="Nhập giá sản phẩm" value="<?php echo e($product->price); ?>" >
                                                </div>
                                                <div class="mb-3">
                                                    <label class="small mb-1" >Giảm giá (%):</label>
                                                    <select id="sale" name="" >
                                                        <option <?php echo e($product->discount==0? 'selected':''); ?> value="no">Không</option>  
                                                        <option <?php echo e($product->discount!=0? 'selected':''); ?> value="yes">Có</option>
                                                    </select>
                                                    <input style="display:<?php echo e($product->discount==0? 'none':'block'); ?>" id="discount" name="discount" class="form-control" type="text" placeholder="Nhập phần trăm giảm giá" >
                                                </div>
                                                <div class="mb-3">
                                                    <label class="small mb-1">Số lượng</label>
                                                    <input name="total" class="form-control" type="text"  id="total" readonly value="<?php echo e($product->total_qty); ?>">
                                                </div>
                                                <div class="mb-3">
                                                    <label class="small mb-1" for="inputUsername">Mô tả</label>
                                                    <textarea name="description" id="editor"><?php echo e($product->description); ?></textarea>
                                                </div>
                                                <button class="btn btn-warning" type="submit">Lưu</button>
                                            
                                        </div>
                                    </div>
                        </form>                  
                        
                        

</div>

<script src="<?php echo e(asset('ckeditor5/ckeditor.js')); ?>"></script>
<script>
    ClassicEditor
        .create( document.querySelector( '#editor' ) )
        .catch( error => {
            console.error( error );
        } );
</script>


<script type="text/javascript">
    $(document).ready(function(){
    // xử lý gọi size theo brand
       $('#brand').change(function(){
        var id_brand=$(this).val();
        $.ajax({
            url: '<?php echo e(route('admin.product.store')); ?>', // đường dẫn đến controller
            method: 'POST', // phương thức POST
            data: { // dữ liệu gửi đi
                id_brand: id_brand, // giá trị id_brand
                _token: '<?php echo e(csrf_token()); ?>' // token để bảo vệ form
            },
            success: function(data){ // nhận kết quả trả về
                if(data != ""){
                // xoá hết bảng cũ thêm bảng mới
                  $('#table_size').html("<table class='table table-bordered'>"+
                                    "<thead>"+
                                        "<tr>"+
                                            "<th class='col-5'>size</th>"+
                                            "<th class='col-7'>số lượng <button class='btn-outline-dark' type='button' style='float:right' id='none_qty'>Chưa có sẵn</button></th>"+
                                        "</tr>"+
                                    "</thead>"+ 
                                    "<tbody>"+
                                    "</tbody>"+
                                "</table>");
                } else {
                     $('#table_size').html("");
                }
              $.each(data, function(index, size) {
                $('#table_size').find('tbody').append("<tr>"+
                                                            "<td>"+size.size+"</td>"+
                                                            "<td >"+
                                                            "<input class='size_qty col-10' type='text' name='size_qty_"+size.id+"'></td>" + 
                                                            "</tr>");
              });

            }
        });  // dấu đóng AJAX
        
      });

       // xử lý xoá hình ảnh đã có của product
       var deleteImage = [];
       $('.delete').click(function(){                //click button xoá
            var nameImage= $(this).data('image');
            deleteImage.push(nameImage);
            $("#listdelete").val(JSON.stringify(deleteImage));
            $(this).closest('div.showimage').remove();
            // nếu xoá hết ảnh thì bắt buộc tải ảnh mới:
            if($(".showimage").length == 0) 
                {
                $("#uploadimage").attr("required", true); 
                }
            
       });

       $('#sale').change(function(){                //sự kiện chọn sale hay không
            if($(this).val()=="yes"){
                $('#discount').show();
                $("#discount").attr("required", true);
            }
            else{
                $("#discount").attr("required", false);
                $('#discount').hide();
            }
       });

        $(document).on('click', '#none_qty', function() {  // gán sự kiện button chưa nhập hàng
            $('#table_size').html("");
            $('#total').val(0);
            $('#size_qty').val('');
        });

        $(document).on('keyup', '.size_qty', function() {  // gán sự kiện keyup cho class size_qty 
            var total = 0;
            $('input.size_qty').each(function(){        
                 var val = parseInt($(this).val());
                total += isNaN(val) ? 0 : val;
            });
            $('#total').val(total); //gán total và input readonly
        });
              
// dấu đóng hàm ready
});

</script>
<?php $__env->stopSection(); ?>
         
<?php echo $__env->make('Admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\chotsport\resources\views/Admin/product/editProduct.blade.php ENDPATH**/ ?>