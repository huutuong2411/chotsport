<?php $__env->startSection('title'); ?>
Quản lý người dùng
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  
<h1 class="h3 mb-2 text-gray-800  border-bottom bg-white mb-4"><i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>Quản lý người dùng</h1>
        <?php if(session('delete')): ?>
            <div class="alert alert-danger">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
              <?php echo e(session('delete')); ?>

            </div>
        <?php endif; ?>
       <?php if($errors->any()): ?>
            <div class="alert alert-danger">
            <ul>
                 <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            </div>
        <?php endif; ?>


        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-check"></i> Thông báo!</h4>
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
<div class="card shadow mb-4">
                        
                        <div class="card">
                          <div class="card-header text-primary font-weight-bold">Danh sách người dùng 
                            <?php if(Auth::user()->id_role==1): ?>
                            <a style="float:right" href="<?php echo e(route('admin.user.addempoyee')); ?>" class="btn btn-primary"><i class="fas fa-plus"></i> Tạo tài khoản nhân viên</a>
                            <?php endif; ?>
                          </div>
                            <div class="card-body table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th class="col-1" style="text-align: center">ID</th>
                                            <th class="col-2" style="text-align: center">Tên</th>
                                            <th class="col-1" style="text-align: center">Avatar</th>
                                            <th class="col-2" style="text-align: center">Email</th>
                                            <th class="col-2" style="text-align: center">Vai trò</th>
                                            <th class="col-2" style="text-align: center">Trạng thái</th>
                                            <th class="col-2" style="text-align: center">Thao tác</th>
                                            
                                        </tr>
                                    </thead>
                                   
                                    <tbody>
                                        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>   
                                            <th scope="row" style="text-align: center"><?php echo e($value->id); ?></th>
                                            <td class="name" style="text-align: center"><?php echo e($value->name); ?></td>
                                            <td class="name" style="text-align: center">
                                            <?php if($value->id_role==1): ?>
                                               <img style="width: 90%" src="<?php echo e(asset('admin/assets/img/user/'.$value->avatar)); ?>" alt=""class="img-profile">
                                            <?php else: ?>
                                                <img style="width: 90%" src="<?php echo e(asset('user/assets/images/user/'.$value->avatar)); ?>" alt=""class="img-profile">
                                            <?php endif; ?>
                                            </td>
                                            <td class="name" style="text-align: center"><?php echo e($value->email); ?></td>
                                            <td class="name" style="text-align: center">
                                                <?php if($value->id_role==1): ?>
                                                <span class="badge badge-success">Quản trị viên</span>
                                                <?php elseif($value->id_role==2): ?>
                                                 <span class="badge badge-warning">Người dùng</span>
                                                  <?php elseif($value->id_role==3): ?>
                                                    <span class="badge badge-info">Nhân viên</span>
                                                  <?php endif; ?>
                                             </td>
                                            <td class="name" style="text-align: center">
                                                <?php if($value->status==0): ?>
                                                <span class="badge badge-success">Kích hoạt</span>
                                                <?php else: ?>
                                                <span class="badge badge-danger">Vô hiệu hoá</span>
                                                <?php endif; ?>
                                            </td>

                                            <td style="text-align: center">
                                                <a href="<?php echo e(route('admin.user.show',['id'=>$value->id])); ?>" class="btn btn-info btn-circle btn-sm" style="margin-left:2%"><i class="fas fa-solid fa-eye"></i></a>
                                                <?php if(Auth::user()->id_role==1 && Auth::user()->id!=$value->id): ?>
                                                <?php if($value->status==0): ?>
                                                <a href="<?php echo e(route('admin.user.disable',['id'=>$value->id])); ?>" class="btn btn-danger btn-circle btn-sm" style="margin-left:2%" title="Vô hiệu hoá"><i class="fas fa-sharp fa-solid fa-ban"></i></a>
                                                <?php else: ?>
                                                <a href="<?php echo e(route('admin.user.enable',['id'=>$value->id])); ?>" class="btn btn-success btn-circle btn-sm" style="margin-left:2%" title="kích hoạt"><i class="fas fa-solid fa-check"></i></a>
                                                <?php endif; ?>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>              
                                    </tbody>
                                </table>
                            </div> 
                        </div>
                        
                        

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\chotsport\resources\views/Admin/user/user.blade.php ENDPATH**/ ?>