<?php 
    $categorys = App\Models\Admin\Category::select('name','id')->get();
    $brands = App\Models\Admin\Brand::select('name','id')->get();
?>
<style type="text/css">
    .selectactive {
            color: #b19361!important;
        }
</style>
<div class="col-lg-3">
                    <!-- Start Sidebar Area -->
                    <div class="siderbar-section" data-aos="fade-up"  data-aos-delay="0">
                        <!-- Start Single Sidebar Widget -->
                        <div class="sidebar-single-widget" >
                            <h6 class="sidebar-title"><a href="<?php echo e(request()->fullUrlWithQuery(['category' =>''])); ?>">DANH MỤC</a></h6>
                            <div class="sidebar-content">
                                <ul class="sidebar-menu">
                                 <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <li><a href="<?php echo e(request()->fullUrlWithQuery(['category' =>$category->id])); ?>" class="<?php echo e(request('category')==$category->id?'nav-link selectactive':''); ?>"><?php echo e($category->name); ?></a></li>   
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                                </ul>
                            </div>
                        </div> <!-- End Single Sidebar Widget -->
                        <form action="<?php echo e(route('user.allproduct')); ?>">
                        <!-- Start Single Sidebar Widget -->
                        <div class="sidebar-single-widget">
                            <h6 class="sidebar-title">Lọc theo giá</h6>
                            <div class="sidebar-content">
                                <div id="slider-range"></div>
                                <div class="filter-type-price">
                                    <label for="amount">Khoảng giá:</label>
                                    <input name="price" type="text" id="amount">
                                </div>
                                <?php if(!empty(request('category'))): ?>
                                    <input type="hidden" name="category"  value="<?php echo e(request('category')); ?>">
                                <?php endif; ?>
                                <?php if(!empty(request('brand'))): ?>
                                    <input type="hidden" name="brand"  value="<?php echo e(request('brand')); ?>">
                                <?php endif; ?>
                                <?php if(!empty(request('price'))): ?>
                                    <input type="hidden" name="sortby"  value="<?php echo e(request('sortby')); ?>">
                                <?php endif; ?>
                                <button class="btn btn-sm btn-golden"><i class="fa-solid fa-filter"></i> Lọc giá</button>
                            </div>
                        </div> <!-- End Single Sidebar Widget -->
                        </form>
                        <div class="sidebar-single-widget" >
                            <h6 class="sidebar-title"><a href="<?php echo e(request()->fullUrlWithQuery(['brand' =>''])); ?>">Thương hiệu</a></h6>
                            <div class="sidebar-content">
                                <ul class="sidebar-menu">
                                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                   <li><a href="<?php echo e(request()->fullUrlWithQuery(['brand' =>$brand->id])); ?>" class="<?php echo e(request('brand')==$brand->id?'nav-link selectactive':''); ?>"><?php echo e($brand->name); ?></a></li>   
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                                </ul>
                            </div>
                        </div> <!-- End Single Sidebar Widget -->


                        <!-- Start Single Sidebar Widget -->
                        <div class="sidebar-single-widget">
                            <div class="sidebar-content">
                                <a href="product-details-default.html" class="sidebar-banner img-hover-zoom">
                                    <img class="img-fluid" src="assets/images/banner/side-banner.jpg" alt="">
                                </a>
                            </div>
                        </div> <!-- End Single Sidebar Widget -->

                    </div> <!-- End Sidebar Area -->
                </div><?php /**PATH C:\xampp\htdocs\chotsport\resources\views/User/layout/left-sidebar.blade.php ENDPATH**/ ?>